# RoadWise NC — Website Starter

This is RoadWise Beta 0.5 repackaged to be published as a normal website.

## Publish free on GitHub Pages

1. Sign in to github.com and create a **public** repository named `roadwise-nc`.
2. Choose **Add file → Upload files** and upload `index.html` from this package into the top level of the repository. Commit.
3. Navigate to **Settings → Pages**, under **Build and deployment** set **Source: Deploy from a branch**, **Branch: main**, folder **/(root)**, then Save.
4. Open the Pages URL shown in Settings → Pages, normally `https://YOUR-USERNAME.github.io/roadwise-nc/`. Deployment can take a few minutes.

## Map access troubleshooting

RoadWise uses remote Leaflet JavaScript/CSS (unpkg.com) and map tile servers (tile.openstreetmap.org and basemaps.cartocdn.com). The website **still requires internet access** and those third-party domains must not be blocked by your device/network. Using GitHub Pages should bypass *local HTML preview* restrictions but won't bypass internet/network filters. If the map does not load on the published website, try another browser/network and look for blocked requests in Developer Tools → Network.

The map is based on real OpenStreetMap data, not a fictional diagram. This version does not include downloadable offline road geometry or automated route selection yet. Always credit OpenStreetMap contributors.
